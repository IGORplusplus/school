#ifndef POSITION_H
#define POSITION_H

struct position{
    int x;
    int y;
};

#endif
