To compile the code:
run the makefile named makefile 
by typing make and run ./project1.exe 
OR




g++ main.cpp cell.cpp region.cpp config.cpp residential.cpp industrial.cpp growth.cpp commercial.cpp
and then run it using what it compiled

Both obviously do the same thing




Some notes:
The residential growth function follows the rules,
but does not end up with the same output as the example
given.

The pollution function is somewhat unclear in its
directions, so I implemented it with the best of my ability.
