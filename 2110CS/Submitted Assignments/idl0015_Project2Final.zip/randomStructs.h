#ifndef RANDOM_H
#define RANDOM_H

#include <iostream>

struct position{
    int x;
    int y;
};


//I know it's cringe but it is a quick bug fix, Sunday is now
//not the beginning of the week
enum Day{
    Sunday = 0,
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday,
};


#endif
