Call the make command to compile all four parts,
each of the executables are numbered in order
