#!/bin/bash
#idl0015
#Igor Leeck

if [[ -n "$1" ]]; then
    echo "Good day, $1! Nice to meet you!"
else
    echo "Hope you have a great day!"
fi
